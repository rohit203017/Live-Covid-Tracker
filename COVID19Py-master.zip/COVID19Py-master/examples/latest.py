import COVID19Py

covid19 = COVID19Py.COVID19()

print(covid19.getLatest())
